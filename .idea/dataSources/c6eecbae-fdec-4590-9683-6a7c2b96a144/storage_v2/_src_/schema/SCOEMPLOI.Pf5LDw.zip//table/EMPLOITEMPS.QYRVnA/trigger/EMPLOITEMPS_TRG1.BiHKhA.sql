create trigger EMPLOITEMPS_TRG1
    before insert
    on EMPLOITEMPS
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

