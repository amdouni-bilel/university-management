create trigger DISPONIBILITE_TRG
    before insert
    on DISPONIBILITE
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

