create trigger EMPLOISEMAINE_TRG
    before insert
    on EMPLOISEMAINE
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

