create trigger EMPLOISEMAINE_TRG1
    before insert
    on EMPLOISEMAINE
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

